package com.cg.appl.services;

import java.util.List; 

import com.cg.appl.entities.Emp;

import com.cg.appl.exceptions.EmpExceptions;


public interface EmpServices {
	Emp getEmpDetails(int empId) throws EmpExceptions;
	List<Emp> getAllEmps() throws EmpExceptions;
	Emp insertNewEmp(Emp emp) throws EmpExceptions;
	Emp updateEmp(Emp emp) throws EmpExceptions;
	boolean deleteEmp(int empId) throws EmpExceptions;
}
